#ifndef SORT_H
#define SORT_H
#include "struct.h"

void sort(product_info pro_info[], int count2);

#endif
