#ifndef MENUOPT_H
#define MENUOPT_H
#include "struct.h"


int menuopt1_input(struct product_info pro_info[], int count2);
int menuopt2_delete(struct product_info pro_info[], int count2);
void menuopt3_list_products(struct product_info pro_info[], int count2);

#endif
