#ifndef DATAHANDLING_H
#define DATAHANDLING_H
#include "struct.h"

int load_data(struct product_info load[]);
void save_data(struct product_info load[], int count2);

#endif
