#ifndef BARCODE_H
#define BARCODE_H
#include "struct.h"


int barcode_search(char barcode[], char menu[], product_info pro_info[], int product);

#endif
